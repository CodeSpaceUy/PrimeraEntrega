<?php

require_once("C:/xampp/htdocs/login/view/head/header.php");

?>


<?php






require_once("C:/xampp/htdocs/login/view/head/footer.php");

?>